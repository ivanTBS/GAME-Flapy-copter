Flappy Bird style game
===============
Source code for a Flappy Bird style game built in Unity3D. You can check a blog post [here](http://dgkanatsios.com/2014/07/02/a-flappy-bird-clone-in-unity-source-code-included-3/) and you can play the game [here](http://unitysamples.azurewebsites.net/flappybirdclone.html)

It has been tested and developed on Unity 5.3
